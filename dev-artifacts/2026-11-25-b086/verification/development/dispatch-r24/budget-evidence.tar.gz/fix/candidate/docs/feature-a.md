# Feature A

Run feature-a list to list entries.
The default order is alphabetical; for example, an entry named apple is listed before one named banana.
