# Feature A

Run feature-a list to list entries.
The default order is alphabetical; for example, `feature-a list` shows an entry named `apple` before an entry named `banana`.
