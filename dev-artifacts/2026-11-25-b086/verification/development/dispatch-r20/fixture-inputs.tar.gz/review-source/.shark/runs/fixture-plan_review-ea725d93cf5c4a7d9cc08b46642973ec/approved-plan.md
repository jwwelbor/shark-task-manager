---
review_baseline: 0b76024a01f67b2d495fded9d2db6ca10d63e6d7
---

Synthetic fixture plan. Document the default order.
