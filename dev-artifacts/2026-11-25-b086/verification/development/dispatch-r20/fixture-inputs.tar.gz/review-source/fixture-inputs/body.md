VERDICT: PASS-with-triage
Scope: Feature A, E01-F01. Findings: Add a worked example under Feature A. Feature A already documents the required command and default. A second worked example can wait.
docs/feature-a.md#DOCS#worked-example
The six angle inputs and the consolidation decision are synthetic. The runner count represents six supplied angle records.
