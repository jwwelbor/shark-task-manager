---
name: finish-feature
description: Finish a feature or fix through candidate-bound review, PR comments, exact-head green CI, the established merge policy, and scoped branch/worktree closeout. Use for "finish this feature", "ship it", "wrap this up", "create a PR and merge it", or /finish-feature. Delegate workspace safeguards to worktree-lifecycle and authorized cleanup to branch-sweep.
---

# Finish feature

Gate through the phases in order. Resume at the earliest invalidated gate after
source or identity changes. Keep integration, workspace closeout, release and
product acceptance distinct in the final report.

## Phase 0 — Establish scope and workspace ownership

Read the installed `worktree-lifecycle` skill through the host catalog or owning
content provider. It is the shared authority for allocation, ownership, delivery
proof and retirement. If unavailable, report the missing dependency and do not
invent substitute cleanup rules.

Record the owning work item, repository, checkout, source branch/head, destination
branch/base, allowed paths and current authorization. Inspect dirty state and
preserve unrelated work. Reuse the assigned active checkout through review and
CI; follow lifecycle allocation rules only when another active assignment needs
isolation. Apply no fixed checkout cap.

Read the project's merge policy and required validation lanes. Do not silently
switch between squash, regular merge or rebase. Resolve an absent policy with
the owner before merging; complete independent preparation while awaiting it.

## Phase 1 — Code review

Run `/shark-rider deep-review high`; use `max` for large or high-risk changes.
Use project-mandated candidate capture, authorization and review binding rather
than recapturing a diff from moving refs. Inspect the persisted runner metadata,
complete coverage and consolidated verdict before continuing.

Complete `canonical-six-angle` or `dispatched-six-angle` reviews may proceed to
CI. A complete `adversarial-cli` review may proceed when the owning review policy
allows it; preserve its actual evidence label. `manual-diagnostic` and
`incomplete` reviews stop before merge unless the user explicitly authorizes the
review-policy exception.

Disposition every finding through the existing triage/project rules: fix now,
verified duplicate, typed tracked follow-up, or justified no-action. Do not map
all non-blockers to debt. Run the required focused and broader validation after
repairs and rebind the candidate as required. Never promote partial review to PASS.

## Phase 2 — Create or update the PR

Confirm the actual source branch/head, destination base and complete task-owned
scope. Use existing project scope artifacts where provided. Push only the
intended branch; keep unrelated files and other owners' work out of the PR.

Use the service connector when sufficient. With the CLI, prepare the exact body
in a file and specify source/destination explicitly:

```bash
git push -u <remote> HEAD:<source-branch>
gh pr create --base <destination-branch> --head <source-branch> \
  --title "<title>" --body-file <prepared-body-file>
```

Reuse an existing matching PR instead of creating a duplicate. Record repository,
PR number, source head and target base for subsequent phases.

## Phase 3 — Resolve PR comments

Run `/resolve-pr-comments` for the recorded PR. Verify the actual fixes and
thread dispositions. Stage explicit task-owned paths and push the intended branch.
Any source change invalidates affected review/validation evidence: return to the
earliest required gate before continuing. Repeat until no unresolved blocking
threads remain and every other finding has a disposition.

## Phase 4 — Verify exact-head CI

Treat green CI as a hard merge gate. Enumerate every project-required and
user-requested lane, including manually dispatched or scheduled workflows that
may not appear in the PR's check rollup. Watch until they finish; if already
complete, verify their final state directly.

```bash
gh pr checks <PR#> --watch
gh pr view <PR#> --json headRefOid,baseRefOid,statusCheckRollup,mergeable,mergeStateStatus
```

Match all evidence to the recorded final head and applicable base. Verify
supplemental workflow run heads and individual job results separately. Pending,
missing, cancelled, skipped or failing required jobs are not passing evidence.
Report skipped tests inside successful suites truthfully; do not silently widen
what a narrower tier proves.

For a failure, read its logs, reproduce the concrete defect, repair its root
cause, and run the appropriate project checks. Format/stage only task-owned
paths; never use broad staging to pick up unrelated changes. Investigate visual
baselines and timing budgets before changing them. Do not skip tests to turn CI
green. Push the repair and return to the earliest invalidated gate.

Immediately before merge, recheck live PR head/base, required review state,
mergeability and the complete expected CI lane set. Old green runs or a changed
base/head do not satisfy this gate by assumption.

## Phase 5 — Merge using the established policy

Enter only with the verified current candidate and existing merge authorization.
Use the service connector with expected head SHA when available. With the CLI,
select the policy's method flag (`--merge`, `--squash` or `--rebase`):

```bash
gh pr merge <PR#> <chosen-method-flag> --match-head-commit <reviewed-head-sha>
```

Do not couple merge with automatic branch deletion. Perform deletion under the
separate lifecycle closeout scope after inspecting newer local work and checkout
ownership. Do not rewrite published history or reset a shared branch to simplify
cleanup.

Verify the PR actually merged and record the returned integration commit. Apply
the lifecycle content-verification procedure at that commit, accounting for any
base/conflict differences. Write the existing closeout's branch/head → PR →
destination evidence before retiring source refs. Do not infer current behavior
or product acceptance solely from historical integration.

## Phase 6 — Scoped workspace closeout

Read and invoke the installed `branch-sweep` skill for this task's exact related
checkout and source refs. Supply the lifecycle closeout evidence, protected paths,
current ownership and existing authorization. Branch-sweep executes the audit and
batch; worktree-lifecycle owns its shared policy. If either dependency is missing,
report workspace closeout incomplete without pretending it ran.

Keep cleanup task-scoped unless the user explicitly requested a broader sweep.
Preserve genuinely active work, repository homes, newer commits and dirty/ignored
state. Never require all worktree listings to become empty. Do not create a new
checkout merely to delete the previous branch, or force-switch/rebase an unrelated
checkout. Reuse exact cleanup authorization already given; request only any still
missing destructive scope after preservation makes the proposed result reviewable.

Verify the exact authorized delta and retained state through the shared procedure.
Report the merge identity, review/CI evidence, removed/retained/skipped workspace
items, and any remaining gate with its owner. A merged feature can still have
pending workspace closeout, release or product acceptance; state each accurately.
