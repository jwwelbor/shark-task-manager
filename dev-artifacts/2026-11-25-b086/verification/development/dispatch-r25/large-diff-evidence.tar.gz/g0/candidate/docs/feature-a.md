# Feature A

Run feature-a list to list entries.
The default order is alphabetical. For example, if the entries are pear and apple, feature-a list shows apple before pear.
