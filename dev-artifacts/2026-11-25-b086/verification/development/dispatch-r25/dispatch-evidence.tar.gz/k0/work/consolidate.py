import subprocess, json, pathlib
C = pathlib.Path('/tmp/b086-r25-dispatch/k0'); W = C/'work'
def obs(*a, stdin=None):
    return subprocess.run(['python3', str(C/'libexec/observe.py'), str(C), *a], input=stdin, capture_output=True, text=True, cwd=C)
s = json.loads((C/'scope/scope.json').read_text())
names = ['angle-a-bugs','angle-b-behavior','angle-c-sibling','angle-d-cleanup','angle-e-tests','angle-f-standards']
angles = {k: json.loads((W/f'{n}.out').read_text()) for k,n in zip('abcdef',names)}
(W/'angles.json').write_text(json.dumps(angles, indent=1))
ref = obs('read','project/.agents/skills/shark-rider/skills/deep-review/references/consolidator.md').stdout
quality = obs('shark','skill','get','quality','workflows/review-code.md','--raw').stdout
plan = (C/'review-repo/docs/plan/bugs/B001.repair-plan.md').read_text()
prompt = f"""# Context preamble
EVIDENCE_MODE: dispatched-six-angle
SPECIALISTS_COMPLETED: 6
CONSOLIDATOR_COMPLETED: true (upon your valid return)
DIFF_PATH: {s['diff_path']}
base_commit: {s['base_commit']}
PROJECT_ROOT: {s['project_root']}
CHANGED_FILES: {json.dumps(s['changed_files'])}
REVIEWED_FILES_REPORTED_BY_ANGLES: {json.dumps(sorted({f for a in angles.values() for f in a['reviewed_files']}))}
CODING_STANDARDS_PATH: null (not found)
entity_type: bug
repair_context: {json.dumps({"plan_revision": "sha256:"+s['repair_plan_sha256'], "accepted_plan": plan, "research": "none supplied", "coverage_evidence": "none supplied", "prior_findings": "none supplied"})}

## Captured scope
{json.dumps(s, indent=1)}
## Diff
{(C/'scope/review.diff').read_text()}
## ALL_FINDINGS (six specialist results)
{json.dumps(angles, indent=1)}
## Constraints
Read-only. Verify coverage. Return the required Markdown report and a candidate-bound decisions JSON object (candidate_identity includes commit, tree, diff_sha256, repair_plan_sha256).

## Consolidator instructions
{ref}
## Canonical craft criteria
{quality}
"""
(W/'consolidator.prompt.md').write_text(prompt)
r = obs('dispatch','consolidator', stdin=prompt)
(W/'consolidator.out').write_text(r.stdout)
print(r.returncode); print(r.stdout); print(r.stderr)
