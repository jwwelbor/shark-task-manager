import subprocess, json, pathlib, concurrent.futures as cf
C = pathlib.Path('/tmp/b086-r25-dispatch/k0'); W = C/'work'
def obs(*a, stdin=None):
    return subprocess.run(['python3', str(C/'libexec/observe.py'), str(C), *a], input=stdin, capture_output=True, text=True, cwd=C)
P = 'project/.agents/skills/shark-rider/skills/deep-review/references/'
scope = (C/'scope/scope.json').read_text(); diff = (C/'scope/review.diff').read_text()
s = json.loads(scope)
quality = obs('shark','skill','get','quality','workflows/review-code.md','--raw').stdout
plan = (C/'review-repo/docs/plan/bugs/B001.repair-plan.md').read_text()
ident = {"commit": s['candidate_commit'], "tree": s['candidate_tree'], "diff_sha256": s['diff_sha256'], "repair_plan_sha256": s['repair_plan_sha256']}
common = f"""# Context preamble
DIFF_PATH: {s['diff_path']}
CHANGED_FILES: {json.dumps(s['changed_files'])}
PROJECT_ROOT: {s['project_root']}
CODING_STANDARDS_PATH: null (not found)
Requested effort: high
entity_type: bug
repair_context: {json.dumps({"plan_revision": "sha256:"+s['repair_plan_sha256'], "accepted_plan_path": "docs/plan/bugs/B001.repair-plan.md", "accepted_plan": plan, "research": "none supplied", "coverage_evidence": "none supplied", "prior_findings": "none supplied"})}
candidate_identity (return exactly): {json.dumps(ident)}

## Complete captured scope
{scope}
## Captured diff
{diff}
## Constraints
Read-only work: no edits, commits, pushes, or PR comments. Return the required JSON schema with candidate_identity containing exactly the captured commit, tree, diff hash and repair_plan_sha256. List every file inspected in reviewed_files.
"""
names = ['angle-a-bugs','angle-b-behavior','angle-c-sibling','angle-d-cleanup','angle-e-tests','angle-f-standards']
def run(n):
    angle = obs('read', P+n+'.md').stdout
    prompt = common + "\n## Assigned angle prompt\n" + angle + "\n## Canonical craft criteria\n" + quality
    (W/f'{n}.prompt.md').write_text(prompt)
    r = obs('dispatch', n, stdin=prompt)
    (W/f'{n}.out').write_text(r.stdout)
    return n, r.returncode, r.stdout, r.stderr
with cf.ThreadPoolExecutor(6) as ex:
    for r in ex.map(run, names):
        print('=====', r[0], r[1]); print(r[2]); print(r[3])
