# Context preamble
DIFF_PATH: /tmp/b086-r25-dispatch/k0/scope/review.diff
CHANGED_FILES: ["docs/feature-a.md", "docs/plan/bugs/B001.repair-plan.md"]
PROJECT_ROOT: /tmp/b086-r25-dispatch/k0/review-repo
CODING_STANDARDS_PATH: null (not found)
Requested effort: high
entity_type: bug
repair_context: {"plan_revision": "sha256:2699aeaf48c49a299a30f63312714bcf34ff3dffd9820bc0d0feb811eb56980f", "accepted_plan_path": "docs/plan/bugs/B001.repair-plan.md", "accepted_plan": "---\nreview_baseline: 0b76024a01f67b2d495fded9d2db6ca10d63e6d7\n---\n\nSynthetic fixture plan. Document the default order.\n", "research": "none supplied", "coverage_evidence": "none supplied", "prior_findings": "none supplied"}
candidate_identity (return exactly): {"commit": "c6bde86451f62fe9255d811bfd9096f78b541481", "tree": "bb91fb7d6281bb8a9221f4a9dd9b787adad745b5", "diff_sha256": "275205ea7e280c0ba6eb1585c54a4df8bdc4274d92ff8b41a27a3123bd7a5fb0", "repair_plan_sha256": "2699aeaf48c49a299a30f63312714bcf34ff3dffd9820bc0d0feb811eb56980f"}

## Complete captured scope
{
  "base_commit": "0b76024a01f67b2d495fded9d2db6ca10d63e6d7",
  "branch": "fixture",
  "candidate_commit": "c6bde86451f62fe9255d811bfd9096f78b541481",
  "candidate_tree": "bb91fb7d6281bb8a9221f4a9dd9b787adad745b5",
  "changed_file_count": 2,
  "changed_files": [
    "docs/feature-a.md",
    "docs/plan/bugs/B001.repair-plan.md"
  ],
  "coding_standards_path": null,
  "diff_path": "/tmp/b086-r25-dispatch/k0/scope/review.diff",
  "diff_sha256": "275205ea7e280c0ba6eb1585c54a4df8bdc4274d92ff8b41a27a3123bd7a5fb0",
  "diff_shortstat": " 2 files changed, 6 insertions(+)",
  "project_root": "/tmp/b086-r25-dispatch/k0/review-repo",
  "repair_plan_sha256": "2699aeaf48c49a299a30f63312714bcf34ff3dffd9820bc0d0feb811eb56980f",
  "review_output_path": "/tmp/b086-r25-dispatch/k0/observations/review/review.md",
  "runtime_project": "."
}

## Captured diff
diff --git a/docs/feature-a.md b/docs/feature-a.md
index b56fe93..f200f17 100644
--- a/docs/feature-a.md
+++ b/docs/feature-a.md
@@ -1,3 +1,4 @@
 # Feature A
 
 Run feature-a list to list entries.
+The default order is alphabetical.
diff --git a/docs/plan/bugs/B001.repair-plan.md b/docs/plan/bugs/B001.repair-plan.md
new file mode 100644
index 0000000..362bdc9
--- /dev/null
+++ b/docs/plan/bugs/B001.repair-plan.md
@@ -0,0 +1,5 @@
+---
+review_baseline: 0b76024a01f67b2d495fded9d2db6ca10d63e6d7
+---
+
+Synthetic fixture plan. Document the default order.

## Constraints
Read-only work: no edits, commits, pushes, or PR comments. Return the required JSON schema with candidate_identity containing exactly the captured commit, tree, diff hash and repair_plan_sha256. List every file inspected in reviewed_files.

## Assigned angle prompt
# Angle C: Cross-File Tracer + Structural Sibling Check

Apply the canonical quality craft rubric for shared thresholds and severity when guidance conflicts.

You are performing a cross-file contract and structural review. You have been given:
- A diff file path (DIFF_PATH)
- A list of changed files (CHANGED_FILES)
- A project root (PROJECT_ROOT)

Substitute these values wherever the instructions say DIFF_PATH, CHANGED_FILES, or PROJECT_ROOT.

---

## Part 1: Cross-file contract tracer

For each function/method the diff changes, find its callers:

```bash
grep -rn "<symbol>" PROJECT_ROOT --include="*.py"   # adjust extension as needed
grep -rn "<symbol>" PROJECT_ROOT --include="*.ts"
```

For each caller, check whether the change breaks the call site:

- **New precondition**: the function now requires a non-None/non-empty argument — does every caller satisfy it?
- **Changed return shape**: the function now returns a different type or structure — do callers handle it?
- **New exception**: the function now raises where it previously returned a value — do callers catch it?
- **Timing / ordering dependency**: the function must now be called after some initialization — is every caller in the correct position?
- **Callees**: does a parallel change in the same PR make an existing call unsafe? (two changes that are each fine in isolation but conflict together)

Pay special attention to functions that **now raise instead of returning a value** — find every caller and verify exception handling.

## Part 2: Structural sibling check

**Mandatory when the diff adds a class that implements a protocol, ABC, or interface.**

When the diff introduces such a class:

1. Find all other implementors:
   ```bash
   # Python
   grep -rn "class.*(<ProtocolName>)" PROJECT_ROOT --include="*.py"
   grep -rn "from.*import.*<ProtocolName>" PROJECT_ROOT --include="*.py"
   # TypeScript
   grep -rn "implements <InterfaceName>" PROJECT_ROOT --include="*.ts"
   grep -rn "extends <BaseName>" PROJECT_ROOT --include="*.ts"
   ```

2. Count the siblings. Check whether they share a common base class that provides real code (not just the protocol signature).

3. Compare implementations: do ≥3 siblings have near-identical method bodies, constructor patterns, or error handling?

Apply the canonical craft rubric's severity rules to the duplication and its
production impact. Report shared-base usage and sibling counts as evidence;
counts alone do not decide severity.

Include a sibling inventory table in your findings when this check triggers:

| Protocol/ABC | Sibling count | Shared base? | New class uses base? | Identical methods |
|---|---|---|---|---|

If the diff does not add a class implementing a protocol/ABC/interface, note "Structural sibling check: not applicable" and skip this part.

## Part 3: Serialization & state-field round-trip

**Mandatory when the diff touches a serialize/deserialize pair OR reads a shared state field.** This catches a class of cross-function contract break that Part 1 misses entirely: the two sides never call each other — they communicate through a serialized key or a shared state object, so signature-based caller tracing never connects them.

1. **Export ↔ import key symmetry.** For any write/read pair the diff touches — `downloadJson`/`importJson`, `toJSON`/`fromJSON`, `encode`/`decode`, `serialize`/`deserialize`, `persist`/`load` — list the keys each side writes and reads. Every key the producer writes must be read under the **same name/path** by the consumer, and vice versa. A key written under one path and read under a different path is a **BLOCKER** (the round-trip silently drops or misreads data).

2. **State-field producer→consumer trace.** For any state field the diff *reads* (e.g. `state.warband.campaign.games`), grep for where that exact path is *written*:
   ```bash
   grep -rn "campaign.games" PROJECT_ROOT --include="*.js"   # adjust path/extension
   ```
   Confirm the writer and the reader use the **same object path**. A reader pointed at a path that no writer ever populates (so it always sees the default/empty value) is a **BLOCKER** — the logic depending on it is dead code. Watch specifically for two parallel state trees (e.g. `state.campaign` vs `state.warband.campaign`) where one is written and the other is read.

Include both the write-site `file:line` and the read-site `file:line` in any finding. If the diff touches neither a serialize/deserialize pair nor a shared-state read, note "Round-trip check: not applicable" and skip.

---

## Output format

```json
{
  "candidate_identity": {"commit": "<captured commit>", "tree": "<captured tree>", "diff_sha256": "<captured hash>"},
  "reviewed_files": ["path/to/file.py"],
  "findings": [
    {
      "file": "path/to/file.py",
      "line": 123,
      "severity": "blocker|non-blocker|nit",
      "rule": "CONTRACT|SIBLING|ROUNDTRIP",
      "summary": "one-sentence description",
      "diagnosis": "what contract is broken, what sibling pattern is violated, or which write/read paths diverge",
      "evidence": "grep output or code showing the issue",
      "correction": "concrete fix"
    }
  ]
}
```

Return the captured `candidate_identity` and `{"reviewed_files": [...], "findings": []}` if nothing found. `reviewed_files` must list every changed file you opened or inspected. Return ONLY the JSON object, no other text.

## Canonical craft criteria
---
inputs:
  - task_id: opaque task identifier (string)
  - task_spec_path: absolute path to the task spec markdown
  - feature_prd_path: absolute path to the feature PRD markdown
  - acceptance_criteria: list of {ac_id, text} extracted from the task spec
  - changed_files: list of absolute paths to files modified by this diff
  - diff_summary: stat summary (files, +lines, -lines) — used for scope sanity
  - language: dominant language(s) of the diff (e.g., "python", "typescript", "go")
  - toolchain: project toolchain commands (test runner, linter, type-checker)
  - coding_standards_path: absolute path to the project's coding-standards.md (optional — if absent, all "standards violations" downgrade to opinion-only nits)
  - architecture_doc_paths: list of absolute paths to system-design / architecture docs (optional)
  - complexity_thresholds: {cyclomatic, file_lines, function_lines} (optional — defaults: 10 / 500 / 50)
  - prior_rejection_count: int — how many times this task has been at code review before (for loop-guard awareness)
  - code_review_report_path: absolute path where the structured report should be written
outputs:
  - verdict: "PASS" | "PASS-with-triage" | "FAIL"
  - code_review_report: structured markdown written to code_review_report_path
  - blockers: list of {finding_id, file_line, rule, diagnosis, evidence, correction}
  - non_blockers_to_triage: list of {finding_id, fingerprint, file_line, rule, summary, fix_suggestion} — host routes each through the triage skill's decision tree (see Step 12); tech-debt is only one possible outcome, never a default. `fingerprint` is a stable identifier (see Step 12) the triage skill searches on so a rerun finding the same defect links or updates the existing entity instead of creating a duplicate.
  - nits: list of {file_line, rule, note} — no action needed
  - counter_factual_per_ac: list of {ac_id, covering_test, rationale_or_blocker_flag}
  - production_caller_chains: list of {service_contract, entrypoint, chain, arg_shape}
  - review_evidence: runner metadata, complete scope and consolidated findings
  - downgrade_justifications: reasons for any downgraded blocker
  - rubric_scores_per_file: list of {file, readability, maintainability, performance, testability, standards, notes}
---

# Workflow: Code Review (Craft Review)

## Purpose

Review code changes for **craftsmanship** — DRY, SOLID, idiomatic patterns, standards compliance, complexity, reuse opportunities — and elevate quality with concrete, actionable feedback. Findings that don't block the task get returned as `non_blockers_to_triage` so they don't get lost.

## Phase Contract

This workflow does **craft review** only. It does NOT re-verify what other phases own:

| What this phase owns | What this phase HANDS OFF to QA |
|---|---|
| DRY / reuse opportunities | Spec fidelity (PRD ↔ implementation) |
| SOLID and architectural compliance | Acceptance criteria verification |
| Standards crosswalk (with citations) | Runtime wiring / call-site verification |
| Idiomatic language patterns | Frontend visual verification |
| Complexity, size, hotspots | Test execution (running pytest, lint, type-check) |
| Reuse search across codebase | E2E reachability |
| Tests **design** review (coverage, boundaries, missing cases) | Codex red-team for spec fidelity |

If you find yourself re-running tests or re-verifying ACs against the PRD, **stop** — that's QA's job. Trust the phase contract; if QA is doing its job, you don't need to re-do it.

A blocker found here halts the task; a non-blocker is returned in `non_blockers_to_triage` so the host can route it through the triage skill's decision tree (full contract in Step 12) — the finding may become a bug, task, question, change, or tech-debt depending on that classification, never tech-debt by default.

### Prompt-only changes

For embedded prompt, skill, template, or documentation-only changes, review
the changed wording against the specification and confirm bundle integrity:
templates render, includes resolve, and newly documented local file references
exist. Do not require a simulated decision table, wording mutation test, or
runtime caller-path trace unless the change alters deterministic runtime
behavior.

## Required inputs (validation)

If any critical input is missing, request it before proceeding. **Do not invent standards or fabricate citations.** If `coding_standards_path` is absent, every standards violation downgrades to opinion-level (nit).

## Review process

### Step 1: Scope sanity (60 seconds — not an AC re-check)

A 5-line gut check, not an AC re-verification:

- Diff touches files plausibly related to the task title.
- Diff size is plausible for the task description (flag if `diff_summary.lines_changed > 2000` — recommend splitting).
- No unrelated modifications.

If the diff doesn't plausibly match the task, **FAIL immediately and return** — something is wrong upstream.

### Step 2: Reuse pass (DRY — search before flagging duplication)

**Before** flagging duplication, search the codebase for existing implementations:

```bash
# Examples — adapt to the language and symbol style
grep -rn "<function-name>" --include="*.py" .
grep -rn "<class-name>" --include="*.ts" src/
rg "<concept>" --type-add 'src:*.{py,ts,tsx,go}' -tsrc
```

For each new utility / helper / abstraction the diff introduces, check whether the codebase already has one. If it does:

- Document the existing symbol with its `file:line`.
- Propose a diff-ready refactor showing how the new code would call it.

Findings: list each duplicated logic with the existing code's location, severity (blocker if a major reimplementation, non-blocker if a small parallel utility).

### Step 3: Standards crosswalk (required citations)

For each finding in this phase, cite the **specific section** of the project's standards docs that the code violates. **No citation = the finding is opinion, not a standards violation.**

For each violation: `{file:line} — {rule} — {coding-standards.md §X.Y "quoted clause"}`.

If the project has no standards section that covers a finding, note "no standards section covers this — opinion only" and downgrade to a nit.

### Step 4: SOLID & architecture compliance

Validate each modified file against:

- **Single Responsibility** — does each class/module have one clear job?
- **Open/Closed** — extensible without modification of stable code paths?
- **Liskov / Interface Segregation / Dependency Inversion** — apply where relevant.
- **Architecture documents** — does the implementation respect the layering, dependency direction, and integration points specified in `architecture_doc_paths`?

For each violation: `file:line`, rule, evidence (code excerpt), and a concrete refactor.

### Step 5: Production caller chain trace (MANDATORY for service-contract changes)

If the diff modifies a service signature, factory, DI wire-up, or any function that production code calls into, **walk the chain end-to-end before signing off.** The most common dead-on-arrival miss is that the diff *compiles* and *unit tests pass* but the production caller cannot actually reach the new code path. Examples that have slipped past CR:

- `vision_client=None` hardcoded in a factory while the feature's whole point was to use vision.
- A repository query that compiles to `WHERE source_page_id IS NULL` against a non-nullable column — always 0 rows.
- A caller passing threshold `0.6` while the service hardcodes `0.7`.

For every changed service contract, name in the report:

1. **Entrypoint** — the production handler / route / CLI command / scheduled job that drives this code in production.
2. **Call chain** — each intermediate `file:line` from entrypoint → leaf.
3. **Argument shape at each hop** — the actual values production passes (not the kwargs a helper-test prefers to use).

If you cannot complete the chain in a 5-line trace, the diff is dead on arrival. **FAIL with finding type ARCH/wiring** and require the developer to add an end-to-end test that calls from the production entrypoint. Reuse the greps from Step 2 — same searches, different question (callers, not duplicates).

Return the chains in `production_caller_chains`.

### Step 6: Idiomatic language review

Apply the language's community-standard patterns.

Use `../context/code-review-reference.md` for the language-specific checklist.

Replace non-idiomatic constructs with community-standard alternatives. Show before/after when the change isn't obvious.

### Step 7: Complexity & size hotspots

Use tooling where available. See `../context/code-review-reference.md` for example commands.

Flag using `complexity_thresholds` (defaults: cyclomatic 10, file 500 lines, function 50 lines, deep nesting ≥4):

- Functions over the cyclomatic threshold.
- Files over the file-line threshold (guide, not hard rule — justify or recommend splitting).
- Functions over the function-line threshold (guide — same).
- Deep nesting.

Pre-existing complexity above threshold is a **non-blocker** (triage) unless the task substantially expanded it. New complexity above threshold is a **blocker**.

### Step 8: Tests review (design, not execution)

You don't run tests — QA does that. But you do review **test design**:

- **Coverage touchpoints** — does each AC have at least one test case?
- **Boundary conditions** — does the test set include min/max/empty/null/zero/negative-one for each input?
- **Negative cases** — what should NOT happen, and is there a test asserting it?
- **Flaky-risk** — tests with timing, random data, network, real time, or shared state.
- **Mock discipline** — tests that only assert the mock was called are not testing real behavior.
- **Missing cases** — given the AC, list any boundary or negative case the test set doesn't cover.

Findings here are typically non-blockers (triaged as test-debt), unless a critical AC has zero tests at all.

### Step 8.5: Counter-factual test check (per AC, MANDATORY)

For each item in `acceptance_criteria`, point at the specific test(s) that cover it and answer one question:

> Would this test fail against the prior buggy code (or against an empty implementation that only satisfies type signatures)?

If the answer is **"no"**, the AC is not actually covered. The test asserts trivia — the class exists, the method returned without raising, the mock was called — but does not exercise the AC's truth condition. Examples that have slipped past CR and were caught only at UAT:

- AC said *"raise when both tiers <3 entries"* — the only test covered tier-2 = 0 (empty), never 1 or 2; a buggy implementation that just truthy-checked the list would pass.
- AC said *"orchestrator raises X when source_blocks empty"* — only the exception class's constructor was tested; the gate path was never exercised.
- AC tested the happy path with kwargs the production caller never actually passes (see Step 5).

For each AC, return one entry in `counter_factual_per_ac`:

```
{
  ac_id: "AC-X",
  covering_test: "test_name at file:line",
  rationale_or_blocker_flag: "[short rationale why this test would fail against the wrong implementation]"
}
```

If you cannot answer, the AC is a non-blocker triage at minimum (developer adds coverage). If the AC is critical and has no test driving the boundary named in the AC text, it is a **blocker** (set rationale_or_blocker_flag accordingly).

### Step 9: Risk hotspots

Identify and flag:

- Complexity concentrations (a single function holding most of the diff's logic).
- Tight coupling (one module reaching into another's internals).
- Performance bottlenecks (N+1 queries, unnecessary loops, blocking I/O on hot paths).
- Security boundaries (input validation, parameterized queries, secrets handling, injection surfaces).
- Concurrency issues (shared state, lock ordering, goroutine leaks).
- I/O boundary risks (network, file, DB calls without timeouts/error handling).

For each: severity, evidence, and a concrete mitigation.

### Step 10: Independent multi-angle review

Use the host's independent multi-angle review procedure and its capability ladder. The host
runs native Workflow, or six dispatched angle reviewers and a consolidator,
or a validated comparable CLI only when dispatch is unavailable. A failed or
partial six-angle run is INCOMPLETE and cannot be replaced by a single CLI
pass. Manual diagnostics are not an unattended pass. Do not launch a separate
nested Codex craft review. Angle reviewers produce evidence only; the parent
retains the lease, heartbeats, transitions and result ingestion.

Freeze the complete scope, including unaccepted predecessor changes. Bind the
review to the candidate tree, diff hash and manifest. Bind the accepted plan
revision when applicable; bug repair reviews require it.
Record runner mode, completed specialists, consolidation, actual reviewer model,
fallback reason, base commit and diff path. Record requested and verified
effective execution identity separately; explicitly mark unknown identity.
If scope or candidate changes, obtain fresh evidence. Preserve disagreements;
justify any downgraded blocker with evidence that it does not mask a test bug,
wiring gap or regressed obligation. Incomplete evidence cannot pass.

### Step 11: Quality rubric (0-5 per dimension)

For each modified file, score 0-5 with a one-sentence justification each. Return in `rubric_scores_per_file`:

- **(a) Readability** — names, structure, flow.
- **(b) Maintainability** — DRY, modularity, clear responsibilities.
- **(c) Performance** — sensible algorithms, no obvious bottlenecks.
- **(d) Testability** — pure functions, dependency injection, seams.
- **(e) Standards Compliance** — adherence to cited standards docs.

Average ≤ 3 for any dimension is a non-blocker triage; ≤ 2 is a blocker.

### Step 12: Triage labeling

For every finding, label it:

| Label | Definition | Goes to |
|---|---|---|
| **Blocker** | AC violation, security flaw, broken contract, missing standards-required behavior, severe complexity in new code | `blockers` — host fails the review |
| **Non-blocker** | Real craft issue but doesn't violate a hard contract — pre-existing complexity, missing nice-to-have test, suggestable refactor, minor reuse opportunity | `non_blockers_to_triage` — host routes through the triage skill's decision tree |
| **Nit** | Stylistic preference, opinion-level, debatable | `nits` — host puts in report only |

The host is responsible for routing every entry in `non_blockers_to_triage` through the triage skill's decision tree (fix-now gate, duplicate search, type classification) before creating any entity — severity ("non-blocker") is not entity type. The fix-now gate may resolve a finding in place with no entity created at all; that counts as triaged. Only findings the decision tree resolves as a maintainability/performance/architectural cost that can safely wait become tech-debt; others may become a bug, task, question, or change instead. Apply the triage skill's unattended review disposition procedure for host authority, verification and parent escalation. Keep delivery pending until every actionable fingerprint has a verified disposition.

**Stable fingerprint.** Compute `fingerprint` for every `non_blockers_to_triage` entry from inputs that survive a line-number shift across review rounds: the file path relative to the repo root, the `rule` category, and a short normalized slug of the finding's defect (lowercase, non-alphanumeric collapsed to `-`, e.g. `dry-duplicated-catch-block`) — never the raw line number, which drifts. Format: `<relative_file_path>#<rule>#<slug>`. The triage skill's duplicate search (Step 3 of its own decision tree) checks existing entities for this exact string before creating a new one; if found, it links/updates that entity instead of filing a second one for the same recurring finding.

## Required output structure (report content)

Write the report to `code_review_report_path`. All sections required:

### A. Executive summary (≤ 10 lines)

- What the diff accomplishes (1-2 lines).
- Overall risk level.
- Verdict: **PASS** / **PASS-with-triage** / **FAIL (blocker)**.
- Counts: blockers / non-blockers triaged / nits.

### B. Findings table

| id | severity | file:line | rule | diagnosis | evidence | correction |
|---|---|---|---|---|---|---|
| 1 | blocker | path/to/file.py:42 | DRY | duplicates `existing_helper()` | `existing_helper()` at lib/helpers.py:18 | replace with import + call |

`rule` is one of: `DRY`, `SRP`, `OCP`, `YAGNI`, `ARCH`, `CODING-STANDARD`, `IDIOM`, `COMPLEXITY`, `RISK`, `TESTS`.

### C. Reuse opportunities

For each duplicated logic: existing symbol + `file:line` + diff-ready refactor.

### D. Standards crosswalk

| finding id | standards doc | section | quoted clause |
|---|---|---|---|

If no standards doc covers a finding, mark "opinion-only" and downgrade severity.

### E. Tests review

- Coverage assessment (which ACs have tests, which don't).
- Missing boundary cases.
- Flaky-risk tests.
- Mock-discipline issues.
- **Counter-factual table** (one row per AC, from `counter_factual_per_ac`).

### F. Quality rubric

| file | readability | maintainability | performance | testability | standards | notes |
|---|---|---|---|---|---|---|

### G. Risk hotspots

Short list, one per category that applies.

### G2. Independent review evidence

Record the Step 10 metadata, scope, findings, disagreements and downgrade justifications.

### H. Production caller chains

From `production_caller_chains` (Step 5). One sub-section per service-contract change in the diff.

### I. Triage summary

- Blockers: list — must fix before QA.
- Non-blockers triaged: list (from `non_blockers_to_triage`) — host routes each through the triage skill's decision tree and includes, per finding, either the resulting entity key (bug, task, question, change, or tech-debt) or "fixed inline" if the decision tree's fix-now gate resolved it without filing one.
- Nits: bullet list, no action.

### J. Verdict

- **PASS** — no findings of any severity.
- **PASS-with-triage** — no blockers; non-blockers exist (host triages).
- **FAIL** — one or more blockers; task returns to development.

For the full report skeleton, see `../context/code-review-reference.md`.

## Decision rules

### Block (request changes) when:

- AC violation that would let the wrong behavior ship.
- Security vulnerability (injection, XSS, auth bypass, secret exposure).
- Architecture violation against a cited section of an architecture doc.
- Duplicated logic of meaningful size without a stated reason.
- New non-idiomatic construct on a critical path.
- Tests have **zero** coverage of a critical AC.
- Performance regression on a documented hot path.
- New code with cyclomatic complexity over the project threshold.
- **Service-contract change without a complete production caller-chain trace** (Step 5).
- **An AC whose only covering test passes against an empty/buggy implementation** (Step 8.5 counter-factual fails for a critical AC).
- **New `except Exception` (or other catch-all: bare `except:`, `catch (Throwable)`, `} catch {}`) introduced by the diff without a stated diagnose-layer justification per the project's error-handling standard.
- **A review blocker downgraded without the Step 10 evidence-based justification.**

### Do **NOT** block for:

- Stylistic preferences within acceptable bounds.
- Pre-existing issues the task didn't substantially worsen (triage instead).
- Minor optimizations that don't affect correctness.
- Naming nits when project standards are met.
- Missing nice-to-have test cases (triage instead).
- **File-organization preferences** (e.g., "split this 700-line test file into smaller groups"). Route through the triage skill's decision tree only if there is concrete maintainability impact; otherwise drop entirely.
- **Micro-style violations on tiny static-data paths** — e.g., a single sync `Path.read_text()` for a small static prompt file inside an `async def`. Async-purity / hot-path rules apply on hot paths; on a 200-byte one-shot read at module init they are nits, not findings.

### Always prefer:

- Minimal, localized fixes over broad rewrites.
- Concrete code in the correction, not vague guidance.
- Acknowledging good work when it's there.

## Self-verification (before returning)

- [ ] Every blocker cites a specific PRD requirement, standards section, or named risk.
- [ ] Every non-blocker has a clear `file_line` + `fingerprint` + `summary` + `fix_suggestion` in `non_blockers_to_triage` so the host can file it without re-reading the report, and reruns link the same entity instead of duplicating it.
- [ ] Reuse search was actually performed (cite at least one grep result, even if "no duplicates found").
- [ ] Standards crosswalk cites real sections from real docs (no fabricated citations).
- [ ] Quality rubric scores are justified with evidence, not vibes.
- [ ] **Independent review completed and findings are incorporated**; incomplete evidence cannot pass.
- [ ] **For each service-contract change in the diff, `production_caller_chains` names entrypoint → call chain → leaf** (Step 5).
- [ ] **`counter_factual_per_ac` has one entry per AC** (Step 8.5) — flag missing coverage as blocker on critical ACs.
- [ ] **Any downgraded blocker has an evidence-based justification** (Step 10).
- [ ] Verdict matches findings: PASS only if zero findings of any severity; PASS-with-triage if no blockers; FAIL otherwise.
- [ ] Report file exists at `code_review_report_path`.

## Edge cases

- **PRD ambiguous or contradictory** — flag explicitly in report; downgrade related findings; do not invent intent.
- **Standards docs conflict** — note the conflict; do not pick a winner without escalation.
- **Diff is tiny (< 50 lines)** — skip rubric scoring; produce a 4-line report.
- **Diff is huge (> 2000 lines)** — recommend splitting in the verdict; review what fits in attention budget; explicitly mark unreviewed regions.
- **No standards doc exists** — every "standards violation" downgrades to opinion-level; recommend running a standards-generation pass.

## Loop-guard awareness

Use the canonical defect-class sweep to classify recurrence from the actual findings and evidence, then apply the project's configured retry and escalation limits. A raw prior rejection count alone does not establish a recurring defect. Preserve prior accepted dispositions unless new evidence invalidates them, and record the basis for any escalation.

## Tone

- Be specific and actionable. Vague feedback ("improve error handling") is not a review.
- Acknowledge good work when it's there — not as flattery, but because reinforcement matters.
- Be direct about blockers; constructive about non-blockers.
- Provide learning context for non-obvious feedback (link to the standards section or pattern doc).
- Respect the developer's effort. The goal is better code shipped, not a higher rejection count.
