# Context preamble
EVIDENCE_MODE: dispatched-six-angle
SPECIALISTS_COMPLETED: 6
CONSOLIDATOR_COMPLETED: true (upon your valid return)
DIFF_PATH: /tmp/b086-r25-dispatch/k0/scope/review.diff
base_commit: 0b76024a01f67b2d495fded9d2db6ca10d63e6d7
PROJECT_ROOT: /tmp/b086-r25-dispatch/k0/review-repo
CHANGED_FILES: ["docs/feature-a.md", "docs/plan/bugs/B001.repair-plan.md"]
REVIEWED_FILES_REPORTED_BY_ANGLES: ["docs/feature-a.md", "docs/plan/bugs/B001.repair-plan.md"]
CODING_STANDARDS_PATH: null (not found)
entity_type: bug
repair_context: {"plan_revision": "sha256:2699aeaf48c49a299a30f63312714bcf34ff3dffd9820bc0d0feb811eb56980f", "accepted_plan": "---\nreview_baseline: 0b76024a01f67b2d495fded9d2db6ca10d63e6d7\n---\n\nSynthetic fixture plan. Document the default order.\n", "research": "none supplied", "coverage_evidence": "none supplied", "prior_findings": "none supplied"}

## Captured scope
{
 "base_commit": "0b76024a01f67b2d495fded9d2db6ca10d63e6d7",
 "branch": "fixture",
 "candidate_commit": "c6bde86451f62fe9255d811bfd9096f78b541481",
 "candidate_tree": "bb91fb7d6281bb8a9221f4a9dd9b787adad745b5",
 "changed_file_count": 2,
 "changed_files": [
  "docs/feature-a.md",
  "docs/plan/bugs/B001.repair-plan.md"
 ],
 "coding_standards_path": null,
 "diff_path": "/tmp/b086-r25-dispatch/k0/scope/review.diff",
 "diff_sha256": "275205ea7e280c0ba6eb1585c54a4df8bdc4274d92ff8b41a27a3123bd7a5fb0",
 "diff_shortstat": " 2 files changed, 6 insertions(+)",
 "project_root": "/tmp/b086-r25-dispatch/k0/review-repo",
 "repair_plan_sha256": "2699aeaf48c49a299a30f63312714bcf34ff3dffd9820bc0d0feb811eb56980f",
 "review_output_path": "/tmp/b086-r25-dispatch/k0/observations/review/review.md",
 "runtime_project": "."
}
## Diff
diff --git a/docs/feature-a.md b/docs/feature-a.md
index b56fe93..f200f17 100644
--- a/docs/feature-a.md
+++ b/docs/feature-a.md
@@ -1,3 +1,4 @@
 # Feature A
 
 Run feature-a list to list entries.
+The default order is alphabetical.
diff --git a/docs/plan/bugs/B001.repair-plan.md b/docs/plan/bugs/B001.repair-plan.md
new file mode 100644
index 0000000..362bdc9
--- /dev/null
+++ b/docs/plan/bugs/B001.repair-plan.md
@@ -0,0 +1,5 @@
+---
+review_baseline: 0b76024a01f67b2d495fded9d2db6ca10d63e6d7
+---
+
+Synthetic fixture plan. Document the default order.

## ALL_FINDINGS (six specialist results)
{
 "a": {
  "candidate_identity": {
   "commit": "c6bde86451f62fe9255d811bfd9096f78b541481",
   "diff_sha256": "275205ea7e280c0ba6eb1585c54a4df8bdc4274d92ff8b41a27a3123bd7a5fb0",
   "repair_plan_sha256": "2699aeaf48c49a299a30f63312714bcf34ff3dffd9820bc0d0feb811eb56980f",
   "tree": "bb91fb7d6281bb8a9221f4a9dd9b787adad745b5"
  },
  "findings": [
   {
    "diagnosis": "A second example would help users apply the default order.",
    "file": "docs/feature-a.md",
    "fingerprint": "docs/feature-a.md#DOCS#worked-example",
    "line": 4,
    "rule": "DOCS",
    "severity": "non-blocker",
    "summary": "Add a worked example under Feature A"
   }
  ],
  "reviewed_files": [
   "docs/feature-a.md",
   "docs/plan/bugs/B001.repair-plan.md"
  ]
 },
 "b": {
  "candidate_identity": {
   "commit": "c6bde86451f62fe9255d811bfd9096f78b541481",
   "diff_sha256": "275205ea7e280c0ba6eb1585c54a4df8bdc4274d92ff8b41a27a3123bd7a5fb0",
   "repair_plan_sha256": "2699aeaf48c49a299a30f63312714bcf34ff3dffd9820bc0d0feb811eb56980f",
   "tree": "bb91fb7d6281bb8a9221f4a9dd9b787adad745b5"
  },
  "findings": [],
  "reviewed_files": [
   "docs/feature-a.md",
   "docs/plan/bugs/B001.repair-plan.md"
  ]
 },
 "c": {
  "candidate_identity": {
   "commit": "c6bde86451f62fe9255d811bfd9096f78b541481",
   "diff_sha256": "275205ea7e280c0ba6eb1585c54a4df8bdc4274d92ff8b41a27a3123bd7a5fb0",
   "repair_plan_sha256": "2699aeaf48c49a299a30f63312714bcf34ff3dffd9820bc0d0feb811eb56980f",
   "tree": "bb91fb7d6281bb8a9221f4a9dd9b787adad745b5"
  },
  "findings": [],
  "reviewed_files": [
   "docs/feature-a.md",
   "docs/plan/bugs/B001.repair-plan.md"
  ]
 },
 "d": {
  "candidate_identity": {
   "commit": "c6bde86451f62fe9255d811bfd9096f78b541481",
   "diff_sha256": "275205ea7e280c0ba6eb1585c54a4df8bdc4274d92ff8b41a27a3123bd7a5fb0",
   "repair_plan_sha256": "2699aeaf48c49a299a30f63312714bcf34ff3dffd9820bc0d0feb811eb56980f",
   "tree": "bb91fb7d6281bb8a9221f4a9dd9b787adad745b5"
  },
  "findings": [],
  "reviewed_files": [
   "docs/feature-a.md",
   "docs/plan/bugs/B001.repair-plan.md"
  ]
 },
 "e": {
  "candidate_identity": {
   "commit": "c6bde86451f62fe9255d811bfd9096f78b541481",
   "diff_sha256": "275205ea7e280c0ba6eb1585c54a4df8bdc4274d92ff8b41a27a3123bd7a5fb0",
   "repair_plan_sha256": "2699aeaf48c49a299a30f63312714bcf34ff3dffd9820bc0d0feb811eb56980f",
   "tree": "bb91fb7d6281bb8a9221f4a9dd9b787adad745b5"
  },
  "findings": [],
  "reviewed_files": [
   "docs/feature-a.md",
   "docs/plan/bugs/B001.repair-plan.md"
  ]
 },
 "f": {
  "candidate_identity": {
   "commit": "c6bde86451f62fe9255d811bfd9096f78b541481",
   "diff_sha256": "275205ea7e280c0ba6eb1585c54a4df8bdc4274d92ff8b41a27a3123bd7a5fb0",
   "repair_plan_sha256": "2699aeaf48c49a299a30f63312714bcf34ff3dffd9820bc0d0feb811eb56980f",
   "tree": "bb91fb7d6281bb8a9221f4a9dd9b787adad745b5"
  },
  "findings": [],
  "reviewed_files": [
   "docs/feature-a.md",
   "docs/plan/bugs/B001.repair-plan.md"
  ]
 }
}
## Constraints
Read-only. Verify coverage. Return the required Markdown report and a candidate-bound decisions JSON object (candidate_identity includes commit, tree, diff_sha256, repair_plan_sha256).

## Consolidator instructions
# Consolidator: Verify, Rank, and Report

You are the final code review consolidator. You receive either six independent angle results or one
complete adversarial alternate-model review. You have been given:
- An EVIDENCE_MODE (`canonical-six-angle`, `dispatched-six-angle`, or `adversarial-cli`)
- SPECIALISTS_COMPLETED and CONSOLIDATOR_COMPLETED metadata
- A diff file path (DIFF_PATH)
- The complete changed file list (CHANGED_FILES)
- The files the review angles reported opening or inspecting (REVIEWED_FILES_REPORTED_BY_ANGLES)
- All candidate findings as JSON (ALL_FINDINGS)

Substitute these values wherever the instructions say DIFF_PATH, CHANGED_FILES, REVIEWED_FILES_REPORTED_BY_ANGLES, or ALL_FINDINGS.

## Evidence-mode rule

Report the actual EVIDENCE_MODE in the Executive Summary and checks performed. Claim “6-angle
automated” only when EVIDENCE_MODE is `canonical-six-angle` or `dispatched-six-angle` and
SPECIALISTS_COMPLETED is exactly 6. For `adversarial-cli`, assess the complete adversarial result
as one review and say so explicitly; do not invent six specialist counts. If the result is empty,
malformed, partial, or CONSOLIDATOR_COMPLETED is false, return **INCOMPLETE** rather than PASS.

For an adversarial result, use its findings and reviewed-scope evidence as the input to the same
verification and triage rules below. A single complete adversarial review can be sufficient for
the pre-merge gate, subject to resolving or explicitly triaging every finding.

---

## Step 1: Scope sanity (quick check)

Before processing findings, do a 5-line gut check on the diff:
- Does the diff touch files plausibly related to the apparent intent of the changes?
- Is the diff size plausible? (Flag if >2000 lines changed — recommend splitting)
- Are there unrelated modifications mixed in?

**Coverage check (mandatory).** Every file in CHANGED_FILES must be addressed by at least one angle's findings or by REVIEWED_FILES_REPORTED_BY_ANGLES. Build the set of files the angles actually touched and diff it against CHANGED_FILES. If any changed file has **zero** coverage from all six angles, flag it as a **coverage gap** — name the unreviewed file(s), record a non-blocker finding, and lower confidence in the verdict accordingly. A clean PASS is only valid when every changed file was actually reviewed. (A review that passes a feature while never opening a heavily-changed file is how production bugs ship.)

**Architectural defensibility check (mandatory).** For any finding or diff section that changes how an existing capability is implemented, wired, configured, persisted, validated, rendered, or tested, state whether the change is defensible to another architect and whether it is the smallest change needed for the desired behavior unless the PR explicitly declares a refactor. Unjustified fundamental changes are blockers when they alter production behavior or create migration cost; otherwise they are non-blocker triage.

If the diff is clearly wrong (wrong branch, massive accidental change), return a FAIL immediately with a scope finding.

## Step 2: Deduplicate

Group findings that refer to the same issue (same file + line + root cause). Keep the most informative version. Note which angles flagged it.

## Step 3: Verify each unique finding

For each finding, read the actual source file around the flagged line and the diff. Rate it:

- **CONFIRMED** — the code demonstrably has this problem
- **PLAUSIBLE** — realistic runtime risk; cannot rule it out from static reading alone
- **REFUTED** — the code proves it factually impossible (e.g., the guard the finding says is missing is on line 5)

Default to PLAUSIBLE for realistic runtime scenarios. Only REFUTE when the code makes it impossible. For every REFUTED blocker, retain a concise refutation naming the exact `file:line`, original summary, and `REFUTED`, with evidence; this permits the host to check that no blocking finding was silently dropped.

**Do NOT refute on current-caller-reachability grounds.** A missing guard on an *exported* / public function, or missing shape-validation at a deserialization / external-input boundary (`JSON.parse`, file import, request body), is **not** "impossible" merely because every *present* caller happens to pass a valid value — future callers are unconstrained and the boundary is real. Downgrade such findings to nit or non-blocker if impact is low, but keep them. REFUTE is reserved for findings the code makes *logically* impossible (the guard already exists, or the branch is unreachable by construction), not findings that merely have no triggering caller today.

## Step 4: Triage labeling

For each surviving finding, assign:

| Label | Criteria |
|---|---|
| **Blocker** | AC violation, security flaw, broken production contract, missing standards-required behavior, unjustified fundamental architecture/workflow change, new complexity over threshold, broad catch-all without justification, or a sibling pattern that violates the canonical craft rubric |
| **Non-blocker** | Real craft issue but doesn't violate a hard contract — pre-existing complexity, missing nice-to-have test, suggestable refactor, minor DRY opportunity, broader-than-necessary but defensible change |
| **Nit** | Stylistic preference, opinion-level, no standards citation |

## Step 5: Quality rubric

For each modified file, score 0–5 with one-sentence justification:
- **Readability** — names, structure, flow
- **Maintainability** — DRY, modularity, clear responsibilities
- **Performance** — sensible algorithms, no obvious bottlenecks
- **Testability** — pure functions, dependency injection, seams
- **Standards Compliance** — adherence to cited standards docs

Average ≤ 3 for any dimension → non-blocker triage. Average ≤ 2 → blocker.

## Step 6: Verdict

- **PASS** — zero findings of any severity
- **PASS-with-triage** — no blockers; non-blockers exist (host routes each through the triage skill's decision tree; tech-debt is only one possible outcome, never a default — see `skills/triage/SKILL.md`'s routing contract). Apply the triage skill's unattended review disposition procedure for host authority, verification and parent escalation. Keep delivery pending until every actionable fingerprint has a verified disposition.
- **FAIL** — one or more blockers; task returns to development

---

## Output: Markdown report

Alongside the Markdown, return candidate-bound `decisions` JSON with
`candidate_identity` and a `findings` array. Each entry records `file`,
positive integer `line`, `severity`, `rule`, `summary`, `diagnosis`, `disposition`, and a nonempty
`reason`. Every raw finding needs a matching entry; use `refuted` only when
the evidence disproves that exact finding. A pass cannot retain an open
blocker. The decisions are machine-checked evidence and do not replace the
reviewer's explanation in the report.

If the verdict is **PASS** and the finding counts are exactly 0 blockers / 0 non-blockers / 0 nits, write a compact saved report only. Do NOT emit the full section set for a clean pass.

### Compact PASS report (zero findings only)

Produce only these sections:

### A. Executive Summary
- What the diff accomplishes (1-2 lines)
- Overall risk level
- Verdict: **PASS**
- Reviewed scope: changed file count, reviewed file count / coverage result
- Checks performed: 6 angles + consolidator, standards path if relevant
- Duration if known
- `0 defects found`

### J. Verdict
**PASS**

One short paragraph summarizing the clean review state and confidence level.

For **PASS-with-triage** or **FAIL**, produce the full detailed report below. Omit any empty section entirely.

### A. Executive Summary
- What the diff accomplishes (1–2 lines)
- Overall risk level
- Verdict: **PASS** / **PASS-with-triage** / **FAIL**
- Counts: X blockers / Y non-blockers triaged / Z nits

### B. Findings Table

| id | severity | file:line | rule | diagnosis | evidence | correction |
|---|---|---|---|---|---|---|

`rule` is one of: `CORRECTNESS`, `WIRING`, `RISK`, `SECURITY`, `REMOVED-BEHAVIOR`, `SRP`, `OCP`, `LSP`, `DIP`, `CONTRACT`, `SIBLING`, `ROUNDTRIP`, `DRY`, `COMPLEXITY`, `IDIOM`, `ALTITUDE`, `ARCHITECTURE`, `TESTS`, `CODING-STANDARD`, `NAMING`, `ERROR-HANDLING`, `TYPES`, `LOGGING`

### C. Reuse Opportunities
For each DRY finding: existing symbol + `file:line` + diff-ready refactor.

### D. Standards Crosswalk
| finding id | standards doc | section | quoted clause |

### E. Tests Review
- Coverage assessment
- Missing boundary / negative cases
- Counter-factual failures (AC + covering test + verdict)
- Flaky-risk tests
- Mock-discipline issues

### F. Quality Rubric
| file | readability | maintainability | performance | testability | standards | notes |

### G. Risk Hotspots
Short list, one per applicable category (security, concurrency, I/O, coupling, performance, architectural drift).

### H. Production Caller Chains
For each service-contract change: entrypoint → call chain → leaf with argument shapes.

### I. Triage Summary
- **Blockers** (must fix before QA): numbered list
- **Non-blockers to triage** (host routes each through the triage skill's decision tree): numbered list with `file:line + fingerprint + summary + fix_suggestion` — `fingerprint` is `<relative_file_path>#<rule>#<slug>` (rule category plus a short normalized defect slug, never the raw line number), so a rerun finding the same defect links the existing entity instead of duplicating it
- **Nits** (no action required): bullet list

### J. Verdict
**PASS** / **PASS-with-triage** / **FAIL**

One paragraph summarizing the state of the PR, what is good, and what must change.

---

## Self-verification before returning

- [ ] Every blocker cites a specific risk, standards section, or named invariant
- [ ] Any fundamental change to an existing architecture/workflow/pattern is explicitly judged as defensible or not defensible
- [ ] Every non-blocker has `file:line + fingerprint + summary + fix_suggestion` so it can be routed through the triage skill's decision tree without re-reading the report, and reruns link the same entity instead of duplicating it
- [ ] Reuse search findings cite at least one grep result (even "no duplicates found")
- [ ] If a structural sibling check was triggered, the sibling inventory table is in section C
- [ ] Standards crosswalk cites real sections (no fabricated citations)
- [ ] Rubric scores are justified with evidence
- [ ] Verdict matches findings: PASS only if zero; PASS-with-triage if no blockers; FAIL otherwise
- [ ] Clean PASS returns only the compact PASS report, not the full section set
- [ ] Do NOT block for: stylistic preferences within acceptable bounds, pre-existing issues the task didn't substantially worsen, minor optimizations, naming nits when standards are met, missing nice-to-have tests, file-organization preferences without concrete maintainability impact

## Canonical craft criteria
---
inputs:
  - task_id: opaque task identifier (string)
  - task_spec_path: absolute path to the task spec markdown
  - feature_prd_path: absolute path to the feature PRD markdown
  - acceptance_criteria: list of {ac_id, text} extracted from the task spec
  - changed_files: list of absolute paths to files modified by this diff
  - diff_summary: stat summary (files, +lines, -lines) — used for scope sanity
  - language: dominant language(s) of the diff (e.g., "python", "typescript", "go")
  - toolchain: project toolchain commands (test runner, linter, type-checker)
  - coding_standards_path: absolute path to the project's coding-standards.md (optional — if absent, all "standards violations" downgrade to opinion-only nits)
  - architecture_doc_paths: list of absolute paths to system-design / architecture docs (optional)
  - complexity_thresholds: {cyclomatic, file_lines, function_lines} (optional — defaults: 10 / 500 / 50)
  - prior_rejection_count: int — how many times this task has been at code review before (for loop-guard awareness)
  - code_review_report_path: absolute path where the structured report should be written
outputs:
  - verdict: "PASS" | "PASS-with-triage" | "FAIL"
  - code_review_report: structured markdown written to code_review_report_path
  - blockers: list of {finding_id, file_line, rule, diagnosis, evidence, correction}
  - non_blockers_to_triage: list of {finding_id, fingerprint, file_line, rule, summary, fix_suggestion} — host routes each through the triage skill's decision tree (see Step 12); tech-debt is only one possible outcome, never a default. `fingerprint` is a stable identifier (see Step 12) the triage skill searches on so a rerun finding the same defect links or updates the existing entity instead of creating a duplicate.
  - nits: list of {file_line, rule, note} — no action needed
  - counter_factual_per_ac: list of {ac_id, covering_test, rationale_or_blocker_flag}
  - production_caller_chains: list of {service_contract, entrypoint, chain, arg_shape}
  - review_evidence: runner metadata, complete scope and consolidated findings
  - downgrade_justifications: reasons for any downgraded blocker
  - rubric_scores_per_file: list of {file, readability, maintainability, performance, testability, standards, notes}
---

# Workflow: Code Review (Craft Review)

## Purpose

Review code changes for **craftsmanship** — DRY, SOLID, idiomatic patterns, standards compliance, complexity, reuse opportunities — and elevate quality with concrete, actionable feedback. Findings that don't block the task get returned as `non_blockers_to_triage` so they don't get lost.

## Phase Contract

This workflow does **craft review** only. It does NOT re-verify what other phases own:

| What this phase owns | What this phase HANDS OFF to QA |
|---|---|
| DRY / reuse opportunities | Spec fidelity (PRD ↔ implementation) |
| SOLID and architectural compliance | Acceptance criteria verification |
| Standards crosswalk (with citations) | Runtime wiring / call-site verification |
| Idiomatic language patterns | Frontend visual verification |
| Complexity, size, hotspots | Test execution (running pytest, lint, type-check) |
| Reuse search across codebase | E2E reachability |
| Tests **design** review (coverage, boundaries, missing cases) | Codex red-team for spec fidelity |

If you find yourself re-running tests or re-verifying ACs against the PRD, **stop** — that's QA's job. Trust the phase contract; if QA is doing its job, you don't need to re-do it.

A blocker found here halts the task; a non-blocker is returned in `non_blockers_to_triage` so the host can route it through the triage skill's decision tree (full contract in Step 12) — the finding may become a bug, task, question, change, or tech-debt depending on that classification, never tech-debt by default.

### Prompt-only changes

For embedded prompt, skill, template, or documentation-only changes, review
the changed wording against the specification and confirm bundle integrity:
templates render, includes resolve, and newly documented local file references
exist. Do not require a simulated decision table, wording mutation test, or
runtime caller-path trace unless the change alters deterministic runtime
behavior.

## Required inputs (validation)

If any critical input is missing, request it before proceeding. **Do not invent standards or fabricate citations.** If `coding_standards_path` is absent, every standards violation downgrades to opinion-level (nit).

## Review process

### Step 1: Scope sanity (60 seconds — not an AC re-check)

A 5-line gut check, not an AC re-verification:

- Diff touches files plausibly related to the task title.
- Diff size is plausible for the task description (flag if `diff_summary.lines_changed > 2000` — recommend splitting).
- No unrelated modifications.

If the diff doesn't plausibly match the task, **FAIL immediately and return** — something is wrong upstream.

### Step 2: Reuse pass (DRY — search before flagging duplication)

**Before** flagging duplication, search the codebase for existing implementations:

```bash
# Examples — adapt to the language and symbol style
grep -rn "<function-name>" --include="*.py" .
grep -rn "<class-name>" --include="*.ts" src/
rg "<concept>" --type-add 'src:*.{py,ts,tsx,go}' -tsrc
```

For each new utility / helper / abstraction the diff introduces, check whether the codebase already has one. If it does:

- Document the existing symbol with its `file:line`.
- Propose a diff-ready refactor showing how the new code would call it.

Findings: list each duplicated logic with the existing code's location, severity (blocker if a major reimplementation, non-blocker if a small parallel utility).

### Step 3: Standards crosswalk (required citations)

For each finding in this phase, cite the **specific section** of the project's standards docs that the code violates. **No citation = the finding is opinion, not a standards violation.**

For each violation: `{file:line} — {rule} — {coding-standards.md §X.Y "quoted clause"}`.

If the project has no standards section that covers a finding, note "no standards section covers this — opinion only" and downgrade to a nit.

### Step 4: SOLID & architecture compliance

Validate each modified file against:

- **Single Responsibility** — does each class/module have one clear job?
- **Open/Closed** — extensible without modification of stable code paths?
- **Liskov / Interface Segregation / Dependency Inversion** — apply where relevant.
- **Architecture documents** — does the implementation respect the layering, dependency direction, and integration points specified in `architecture_doc_paths`?

For each violation: `file:line`, rule, evidence (code excerpt), and a concrete refactor.

### Step 5: Production caller chain trace (MANDATORY for service-contract changes)

If the diff modifies a service signature, factory, DI wire-up, or any function that production code calls into, **walk the chain end-to-end before signing off.** The most common dead-on-arrival miss is that the diff *compiles* and *unit tests pass* but the production caller cannot actually reach the new code path. Examples that have slipped past CR:

- `vision_client=None` hardcoded in a factory while the feature's whole point was to use vision.
- A repository query that compiles to `WHERE source_page_id IS NULL` against a non-nullable column — always 0 rows.
- A caller passing threshold `0.6` while the service hardcodes `0.7`.

For every changed service contract, name in the report:

1. **Entrypoint** — the production handler / route / CLI command / scheduled job that drives this code in production.
2. **Call chain** — each intermediate `file:line` from entrypoint → leaf.
3. **Argument shape at each hop** — the actual values production passes (not the kwargs a helper-test prefers to use).

If you cannot complete the chain in a 5-line trace, the diff is dead on arrival. **FAIL with finding type ARCH/wiring** and require the developer to add an end-to-end test that calls from the production entrypoint. Reuse the greps from Step 2 — same searches, different question (callers, not duplicates).

Return the chains in `production_caller_chains`.

### Step 6: Idiomatic language review

Apply the language's community-standard patterns.

Use `../context/code-review-reference.md` for the language-specific checklist.

Replace non-idiomatic constructs with community-standard alternatives. Show before/after when the change isn't obvious.

### Step 7: Complexity & size hotspots

Use tooling where available. See `../context/code-review-reference.md` for example commands.

Flag using `complexity_thresholds` (defaults: cyclomatic 10, file 500 lines, function 50 lines, deep nesting ≥4):

- Functions over the cyclomatic threshold.
- Files over the file-line threshold (guide, not hard rule — justify or recommend splitting).
- Functions over the function-line threshold (guide — same).
- Deep nesting.

Pre-existing complexity above threshold is a **non-blocker** (triage) unless the task substantially expanded it. New complexity above threshold is a **blocker**.

### Step 8: Tests review (design, not execution)

You don't run tests — QA does that. But you do review **test design**:

- **Coverage touchpoints** — does each AC have at least one test case?
- **Boundary conditions** — does the test set include min/max/empty/null/zero/negative-one for each input?
- **Negative cases** — what should NOT happen, and is there a test asserting it?
- **Flaky-risk** — tests with timing, random data, network, real time, or shared state.
- **Mock discipline** — tests that only assert the mock was called are not testing real behavior.
- **Missing cases** — given the AC, list any boundary or negative case the test set doesn't cover.

Findings here are typically non-blockers (triaged as test-debt), unless a critical AC has zero tests at all.

### Step 8.5: Counter-factual test check (per AC, MANDATORY)

For each item in `acceptance_criteria`, point at the specific test(s) that cover it and answer one question:

> Would this test fail against the prior buggy code (or against an empty implementation that only satisfies type signatures)?

If the answer is **"no"**, the AC is not actually covered. The test asserts trivia — the class exists, the method returned without raising, the mock was called — but does not exercise the AC's truth condition. Examples that have slipped past CR and were caught only at UAT:

- AC said *"raise when both tiers <3 entries"* — the only test covered tier-2 = 0 (empty), never 1 or 2; a buggy implementation that just truthy-checked the list would pass.
- AC said *"orchestrator raises X when source_blocks empty"* — only the exception class's constructor was tested; the gate path was never exercised.
- AC tested the happy path with kwargs the production caller never actually passes (see Step 5).

For each AC, return one entry in `counter_factual_per_ac`:

```
{
  ac_id: "AC-X",
  covering_test: "test_name at file:line",
  rationale_or_blocker_flag: "[short rationale why this test would fail against the wrong implementation]"
}
```

If you cannot answer, the AC is a non-blocker triage at minimum (developer adds coverage). If the AC is critical and has no test driving the boundary named in the AC text, it is a **blocker** (set rationale_or_blocker_flag accordingly).

### Step 9: Risk hotspots

Identify and flag:

- Complexity concentrations (a single function holding most of the diff's logic).
- Tight coupling (one module reaching into another's internals).
- Performance bottlenecks (N+1 queries, unnecessary loops, blocking I/O on hot paths).
- Security boundaries (input validation, parameterized queries, secrets handling, injection surfaces).
- Concurrency issues (shared state, lock ordering, goroutine leaks).
- I/O boundary risks (network, file, DB calls without timeouts/error handling).

For each: severity, evidence, and a concrete mitigation.

### Step 10: Independent multi-angle review

Use the host's independent multi-angle review procedure and its capability ladder. The host
runs native Workflow, or six dispatched angle reviewers and a consolidator,
or a validated comparable CLI only when dispatch is unavailable. A failed or
partial six-angle run is INCOMPLETE and cannot be replaced by a single CLI
pass. Manual diagnostics are not an unattended pass. Do not launch a separate
nested Codex craft review. Angle reviewers produce evidence only; the parent
retains the lease, heartbeats, transitions and result ingestion.

Freeze the complete scope, including unaccepted predecessor changes. Bind the
review to the candidate tree, diff hash and manifest. Bind the accepted plan
revision when applicable; bug repair reviews require it.
Record runner mode, completed specialists, consolidation, actual reviewer model,
fallback reason, base commit and diff path. Record requested and verified
effective execution identity separately; explicitly mark unknown identity.
If scope or candidate changes, obtain fresh evidence. Preserve disagreements;
justify any downgraded blocker with evidence that it does not mask a test bug,
wiring gap or regressed obligation. Incomplete evidence cannot pass.

### Step 11: Quality rubric (0-5 per dimension)

For each modified file, score 0-5 with a one-sentence justification each. Return in `rubric_scores_per_file`:

- **(a) Readability** — names, structure, flow.
- **(b) Maintainability** — DRY, modularity, clear responsibilities.
- **(c) Performance** — sensible algorithms, no obvious bottlenecks.
- **(d) Testability** — pure functions, dependency injection, seams.
- **(e) Standards Compliance** — adherence to cited standards docs.

Average ≤ 3 for any dimension is a non-blocker triage; ≤ 2 is a blocker.

### Step 12: Triage labeling

For every finding, label it:

| Label | Definition | Goes to |
|---|---|---|
| **Blocker** | AC violation, security flaw, broken contract, missing standards-required behavior, severe complexity in new code | `blockers` — host fails the review |
| **Non-blocker** | Real craft issue but doesn't violate a hard contract — pre-existing complexity, missing nice-to-have test, suggestable refactor, minor reuse opportunity | `non_blockers_to_triage` — host routes through the triage skill's decision tree |
| **Nit** | Stylistic preference, opinion-level, debatable | `nits` — host puts in report only |

The host is responsible for routing every entry in `non_blockers_to_triage` through the triage skill's decision tree (fix-now gate, duplicate search, type classification) before creating any entity — severity ("non-blocker") is not entity type. The fix-now gate may resolve a finding in place with no entity created at all; that counts as triaged. Only findings the decision tree resolves as a maintainability/performance/architectural cost that can safely wait become tech-debt; others may become a bug, task, question, or change instead. Apply the triage skill's unattended review disposition procedure for host authority, verification and parent escalation. Keep delivery pending until every actionable fingerprint has a verified disposition.

**Stable fingerprint.** Compute `fingerprint` for every `non_blockers_to_triage` entry from inputs that survive a line-number shift across review rounds: the file path relative to the repo root, the `rule` category, and a short normalized slug of the finding's defect (lowercase, non-alphanumeric collapsed to `-`, e.g. `dry-duplicated-catch-block`) — never the raw line number, which drifts. Format: `<relative_file_path>#<rule>#<slug>`. The triage skill's duplicate search (Step 3 of its own decision tree) checks existing entities for this exact string before creating a new one; if found, it links/updates that entity instead of filing a second one for the same recurring finding.

## Required output structure (report content)

Write the report to `code_review_report_path`. All sections required:

### A. Executive summary (≤ 10 lines)

- What the diff accomplishes (1-2 lines).
- Overall risk level.
- Verdict: **PASS** / **PASS-with-triage** / **FAIL (blocker)**.
- Counts: blockers / non-blockers triaged / nits.

### B. Findings table

| id | severity | file:line | rule | diagnosis | evidence | correction |
|---|---|---|---|---|---|---|
| 1 | blocker | path/to/file.py:42 | DRY | duplicates `existing_helper()` | `existing_helper()` at lib/helpers.py:18 | replace with import + call |

`rule` is one of: `DRY`, `SRP`, `OCP`, `YAGNI`, `ARCH`, `CODING-STANDARD`, `IDIOM`, `COMPLEXITY`, `RISK`, `TESTS`.

### C. Reuse opportunities

For each duplicated logic: existing symbol + `file:line` + diff-ready refactor.

### D. Standards crosswalk

| finding id | standards doc | section | quoted clause |
|---|---|---|---|

If no standards doc covers a finding, mark "opinion-only" and downgrade severity.

### E. Tests review

- Coverage assessment (which ACs have tests, which don't).
- Missing boundary cases.
- Flaky-risk tests.
- Mock-discipline issues.
- **Counter-factual table** (one row per AC, from `counter_factual_per_ac`).

### F. Quality rubric

| file | readability | maintainability | performance | testability | standards | notes |
|---|---|---|---|---|---|---|

### G. Risk hotspots

Short list, one per category that applies.

### G2. Independent review evidence

Record the Step 10 metadata, scope, findings, disagreements and downgrade justifications.

### H. Production caller chains

From `production_caller_chains` (Step 5). One sub-section per service-contract change in the diff.

### I. Triage summary

- Blockers: list — must fix before QA.
- Non-blockers triaged: list (from `non_blockers_to_triage`) — host routes each through the triage skill's decision tree and includes, per finding, either the resulting entity key (bug, task, question, change, or tech-debt) or "fixed inline" if the decision tree's fix-now gate resolved it without filing one.
- Nits: bullet list, no action.

### J. Verdict

- **PASS** — no findings of any severity.
- **PASS-with-triage** — no blockers; non-blockers exist (host triages).
- **FAIL** — one or more blockers; task returns to development.

For the full report skeleton, see `../context/code-review-reference.md`.

## Decision rules

### Block (request changes) when:

- AC violation that would let the wrong behavior ship.
- Security vulnerability (injection, XSS, auth bypass, secret exposure).
- Architecture violation against a cited section of an architecture doc.
- Duplicated logic of meaningful size without a stated reason.
- New non-idiomatic construct on a critical path.
- Tests have **zero** coverage of a critical AC.
- Performance regression on a documented hot path.
- New code with cyclomatic complexity over the project threshold.
- **Service-contract change without a complete production caller-chain trace** (Step 5).
- **An AC whose only covering test passes against an empty/buggy implementation** (Step 8.5 counter-factual fails for a critical AC).
- **New `except Exception` (or other catch-all: bare `except:`, `catch (Throwable)`, `} catch {}`) introduced by the diff without a stated diagnose-layer justification per the project's error-handling standard.
- **A review blocker downgraded without the Step 10 evidence-based justification.**

### Do **NOT** block for:

- Stylistic preferences within acceptable bounds.
- Pre-existing issues the task didn't substantially worsen (triage instead).
- Minor optimizations that don't affect correctness.
- Naming nits when project standards are met.
- Missing nice-to-have test cases (triage instead).
- **File-organization preferences** (e.g., "split this 700-line test file into smaller groups"). Route through the triage skill's decision tree only if there is concrete maintainability impact; otherwise drop entirely.
- **Micro-style violations on tiny static-data paths** — e.g., a single sync `Path.read_text()` for a small static prompt file inside an `async def`. Async-purity / hot-path rules apply on hot paths; on a 200-byte one-shot read at module init they are nits, not findings.

### Always prefer:

- Minimal, localized fixes over broad rewrites.
- Concrete code in the correction, not vague guidance.
- Acknowledging good work when it's there.

## Self-verification (before returning)

- [ ] Every blocker cites a specific PRD requirement, standards section, or named risk.
- [ ] Every non-blocker has a clear `file_line` + `fingerprint` + `summary` + `fix_suggestion` in `non_blockers_to_triage` so the host can file it without re-reading the report, and reruns link the same entity instead of duplicating it.
- [ ] Reuse search was actually performed (cite at least one grep result, even if "no duplicates found").
- [ ] Standards crosswalk cites real sections from real docs (no fabricated citations).
- [ ] Quality rubric scores are justified with evidence, not vibes.
- [ ] **Independent review completed and findings are incorporated**; incomplete evidence cannot pass.
- [ ] **For each service-contract change in the diff, `production_caller_chains` names entrypoint → call chain → leaf** (Step 5).
- [ ] **`counter_factual_per_ac` has one entry per AC** (Step 8.5) — flag missing coverage as blocker on critical ACs.
- [ ] **Any downgraded blocker has an evidence-based justification** (Step 10).
- [ ] Verdict matches findings: PASS only if zero findings of any severity; PASS-with-triage if no blockers; FAIL otherwise.
- [ ] Report file exists at `code_review_report_path`.

## Edge cases

- **PRD ambiguous or contradictory** — flag explicitly in report; downgrade related findings; do not invent intent.
- **Standards docs conflict** — note the conflict; do not pick a winner without escalation.
- **Diff is tiny (< 50 lines)** — skip rubric scoring; produce a 4-line report.
- **Diff is huge (> 2000 lines)** — recommend splitting in the verdict; review what fits in attention budget; explicitly mark unreviewed regions.
- **No standards doc exists** — every "standards violation" downgrades to opinion-level; recommend running a standards-generation pass.

## Loop-guard awareness

Use the canonical defect-class sweep to classify recurrence from the actual findings and evidence, then apply the project's configured retry and escalation limits. A raw prior rejection count alone does not establish a recurring defect. Preserve prior accepted dispositions unless new evidence invalidates them, and record the basis for any escalation.

## Tone

- Be specific and actionable. Vague feedback ("improve error handling") is not a review.
- Acknowledge good work when it's there — not as flattery, but because reinforcement matters.
- Be direct about blockers; constructive about non-blockers.
- Provide learning context for non-obvious feedback (link to the standards section or pattern doc).
- Respect the developer's effort. The goal is better code shipped, not a higher rejection count.

