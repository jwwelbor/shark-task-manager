import json,pathlib,subprocess,sys
K=pathlib.Path('/tmp/b086-r25-dispatch/k1'); W=K/'work'
A={}
for k in 'abcdef':
    t=(W/f'{k}.out').read_text()
    try: A[k]=json.loads(t); print(k,'valid',len(A[k]['findings']))
    except ValueError as e: A[k]={"malformed_raw_output":t}; print(k,'MALFORMED',len(t),e)
(W/'angles.json').write_text(json.dumps(A,indent=1))
n=sum('malformed_raw_output' not in v for v in A.values())
(W/'body.md').write_text(f"""**INCOMPLETE**

## Executive Summary
Host-dispatched review of candidate c6bde86451f62fe9255d811bfd9096f78b541481 (2 changed files).
{n} of 6 angle reviewers returned valid results. Angle C (contracts/siblings) returned truncated, unparseable JSON.
The consolidator was not dispatched. No PASS or FAIL verdict exists, and the review does not admit CI or merge.

## Unconsolidated findings (not verified or dispositioned)
- Angle A, non-blocker, docs/feature-a.md:4, DOCS: "Add a worked example under Feature A". Diagnosis: a second example would help users apply the default order.
- Angles B, D, E, F returned no findings. Angle C findings are unknown.

## Next step
Obtain fresh, complete six-angle evidence and consolidation for this candidate.
""")
r=subprocess.run([sys.executable,str(K/'libexec/observe.py'),str(K),'report','--body-file',str(W/'body.md'),'--runner-mode','incomplete','--specialists-completed',str(n),'--consolidator-completed','false','--adversarial-model','none','--fallback-reason','native Workflow unavailable; angle C returned malformed truncated JSON; consolidator not dispatched','--verdict','INCOMPLETE','--angle-results',str(W/'angles.json')],capture_output=True,text=True)
print(r.returncode,r.stdout,r.stderr)
