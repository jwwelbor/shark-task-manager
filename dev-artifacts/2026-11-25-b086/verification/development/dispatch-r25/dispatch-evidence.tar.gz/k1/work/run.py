exec(open('/tmp/b086-r25-dispatch/k1/work/build.py').read())
names={'a':'angle-a-bugs','b':'angle-b-behavior','c':'angle-c-sibling','d':'angle-d-cleanup','e':'angle-e-tests','f':'angle-f-standards'}
def go(k):
    n=names[k]; p=rec('read',ref+n+'.md'); assert p.returncode==0,p.stderr
    r=rec('dispatch',n,stdin=p.stdout+"\n\n"+pre)
    (W/f'{k}.out').write_text(r.stdout); return k,r.returncode,r.stdout,r.stderr
with cf.ThreadPoolExecutor(6) as ex:
    for x in ex.map(go,names): print(x)
