import json,subprocess,sys,pathlib,concurrent.futures as cf
K=pathlib.Path('/tmp/b086-r25-dispatch/k1'); W=K/'work'
def rec(*a,stdin=None):
    return subprocess.run([sys.executable,str(K/'libexec/observe.py'),str(K),*a],input=stdin,text=True,capture_output=True)
ref='project/.agents/skills/shark-rider/skills/deep-review/references/'
scope=(K/'scope/scope.json').read_text(); s=json.loads(scope)
diff=(K/'scope/review.diff').read_text()
plan=(K/'review-repo/docs/plan/bugs/B001.repair-plan.md').read_text()
craft=subprocess.run([str(K/'project/shark'),'skill','get','quality','workflows/review-code.md','--raw'],capture_output=True,text=True,check=True,cwd=K/'project').stdout
ident={"commit":s["candidate_commit"],"tree":s["candidate_tree"],"diff_sha256":s["diff_sha256"],"repair_plan_sha256":s["repair_plan_sha256"]}
pre=f"""CAPTURED SCOPE:
{scope}
DIFF_PATH: {s['diff_path']}
CHANGED_FILES: {json.dumps(s['changed_files'])}
PROJECT_ROOT: {s['project_root']}
entity_type=bug
repair_context: plan_revision=sha256:{s['repair_plan_sha256']}; accepted plan (revision above):
{plan}
No research, coverage evidence or prior findings were supplied.
candidate_identity (return exactly): {json.dumps(ident)}
CONSTRAINTS: read-only; no edits, commits, pushes or PR comments; return the required JSON schema with candidate_identity; list every file inspected in reviewed_files.
DIFF:
{diff}
CANONICAL CRAFT CRITERIA:
{craft}
"""
(W/'preamble.txt').write_text(pre)
