exec(open('/tmp/b086-r25-dispatch/k1/work/build.py').read())
A={k:json.loads((W/f'{k}.out').read_text()) for k in 'abcdef'}
(W/'angles.json').write_text(json.dumps(A,indent=1))
p=rec('read',ref+'consolidator.md'); assert p.returncode==0
allf=[f for k in 'abcdef' for f in A[k]['findings']]
msg=p.stdout+f"""

EVIDENCE_MODE: dispatched-six-angle
SPECIALISTS_COMPLETED: 6
CONSOLIDATOR_COMPLETED: true (upon your valid return)
REVIEWED_FILES_REPORTED_BY_ANGLES: {json.dumps({k:A[k]['reviewed_files'] for k in A})}
ALL_FINDINGS: {json.dumps(allf)}
SIX ANGLE RESULTS: {json.dumps(A)}
Return the Markdown report and the decisions JSON object (candidate_identity must include repair_plan_sha256; each decision copies file, line, rule, summary, diagnosis exactly).
"""+pre
r=rec('dispatch','consolidator',stdin=msg)
(W/'consolidator.out').write_text(r.stdout); print(r.returncode,r.stderr); print(r.stdout)
