# Feature A

Run feature-a list to list entries.
The default order is alphabetical. For example, with entries pear and apple, the list shows apple first.
